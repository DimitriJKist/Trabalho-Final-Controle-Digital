figure;
plot(tempo_simulado,saida_simulada, '-', 'Color', [0.4000    1.0000    0.4000], 'LineWidth', 3);
hold on;
plot(tempo_experimental, saida_experimental, '-','Color', [0.7922    0.4588    1.0000], 'LineWidth', 2);
plot(tempo_experimental, ref-12, '--','Color', 'b', 'LineWidth', 1);
grid on;
legend('Simulado ','Experimental', 'Referência', 'Location', 'best', 'NumColumns', 1, 'FontSize', 11);
xlabel('Tempo (s)');
ylabel('Nível [cm]');
xlim([0, 120]);
%ylim([-2.2,6.9]);   
hold off;

hold on;
figure;
plot(tempo_simulado, esforco_simulado, '-', 'Color', [0.4000    1.0000    0.4000], 'LineWidth', 3);
hold on;
plot(tempo_experimental, esforco_experimental, '-', 'Color', [0.7922    0.4588    1.0000], 'LineWidth', 2);
grid on;
legend('Simulado ', 'Experimental', 'Location', 'best', 'NumColumns', 1, 'FontSize', 11);
xlabel('Tempo (s)');
ylabel('Ação de controle    [V]');
xlim([0, 120]);
ylim([0,12]); 


figure;

plot(tempo, altura-12, '-', 'Color', [0.4000    1.0000    0.4000], 'LineWidth', 2);
hold on;
plot(tempo, ref-12, '--', 'LineWidth', 2);
plot(out.time, out.saida_pi_simulado, '-', 'Color', [0.7922    0.4588    1.0000], 'LineWidth', 2);
grid on;
legend('Experimental ','Referência', 'Simulação', 'Location', 'best', 'NumColumns', 1, 'FontSize', 14);
xlabel('Tempo (s)');
ylabel('Saída [cm]');
%xlim([0, 9]);
%ylim([-2.2,6.9]);  

figure;
plot(tempo, acao_controle, '-', 'Color', [0.4000    1.0000    0.4000], 'LineWidth', 2);
hold on;
plot(out.time, out.esforco_pi_simulado, '--', 'Color', [0.7922    0.4588    1.0000], 'LineWidth', 2);
grid on;
legend('Experimental ', 'Simulação', 'Location', 'best', 'NumColumns', 1, 'FontSize', 14);
xlabel('Tempo (s)');
ylabel('Saída [V]');
%xlim([0, 9]);
ylim([0,12]);   

close all;


figure;

plot(tempo_altus,  altura_altus-12, '-', 'Color', [0.4000    1.0000    0.4000], 'LineWidth', 2);
hold on;
plot(tempo, ref-12, '--', 'LineWidth', 2);
plot(out.time, out.saida_pi_simulado, '-', 'Color', [0.7922    0.4588    1.0000], 'LineWidth', 2);
grid on;
legend('Experimental ','Referência', 'Simulação', 'Location', 'best', 'NumColumns', 1, 'FontSize', 14);
xlabel('Tempo (s)');
ylabel('Saída [cm]');
%xlim([0, 9]);
%ylim([-2.2,6.9]);  

figure;
plot(tempo_altus, acao_controlealtus, '-', 'Color', [0.4000    1.0000    0.4000], 'LineWidth', 2);
hold on;
plot(out.time, out.esforco_pi_simulado, '--', 'Color', [0.7922    0.4588    1.0000], 'LineWidth', 2);
grid on;
legend('Experimental ', 'Simulação', 'Location', 'best', 'NumColumns', 1, 'FontSize', 14);
xlabel('Tempo (s)');
ylabel('Saída [V]');
%xlim([0, 9]);
ylim([0,12]); 


