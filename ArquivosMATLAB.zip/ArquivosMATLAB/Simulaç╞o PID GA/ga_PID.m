% Genetic Algorithm to tune PID
n_var = 3; % Número de variáveis [K_P, T_I,T_D]
lb = [0,   0, 0]; % Limites inferiores
ub = [10, 1, 0.1]; % Limites superiores
gen = 25; % Número de gerações
pop = 20; % Tamanho da população
% Fixar semente de aleatoriedade para reprodutibilidade
rng(42);

ga_opt = optimoptions('ga', ...
    'Display', 'iter', ...
    'MaxGenerations', gen, ...
    'PopulationSize', pop, ...
    'MutationFcn', @mutationadaptfeasible, ...
    'PlotFcn', @gaplotbestf); % Plot best fitness function

%Função objetivo
obj_fn = @(k) optimization_PID(k); % Define the objective function

[k, best] = ga(obj_fn, n_var, [], [], [], [], lb, ub, [], ga_opt);

disp('Optimal PID Parameters:');
disp(k);
disp('Best Fitness Value:');
disp(best);
