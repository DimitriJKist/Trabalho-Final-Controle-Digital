% Script de inicialização para o Simulink

% Definir variáveis globais
global u_ant y_ant u_D_ant u_I_ant;

% Inicializar as variáveis globais
u_ant = 0;      % Valor inicial do controle (u[n-1])
y_ant = 0;      % Valor inicial da saída (y[n-1])
u_I_ant = 0;    % Valor inicial da integral (termo I anterior)
u_D_ant = 0;    % Valor inicial do derivativo (termo D anterior)

% Configurar parâmetros do sistema
Ts = 1 / 50;    % Período de amostragem (em segundos)
K_P = 1;        % Ganho proporcional (Kp)
T_I = 4;        % Constante de tempo do integrador (Ti)
T_t = 0.2;      % Constante do anti-windup (Tt)
T_D = 0.5;      % Constante de tempo derivativa (Td)
sat = 10;       % Saturação do controlador
N = 15;        % Fator de filtro derivativo

% Criar vetor de parâmetros
param = [Ts, K_P, T_I, sat];
k = [K_P, T_I, T_D];

% Adicionar o script ao Workspace do Simulink
assignin('base', 'param', param);
assignin('base', 'k', k);

% Mensagem de conclusão
disp('Variáveis globais e parâmetros inicializados no Workspace.');
