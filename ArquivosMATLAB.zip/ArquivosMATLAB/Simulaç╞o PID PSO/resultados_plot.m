% Ler os dados da tabela
data = readtable('teste_109_angulo.dat');

% Selecionar a coluna a ser filtrada
coluna = data.x16519200000000Fa05;
t = linspace(0, 8, length(coluna));
t = t';
u=180*ones(length(coluna),1);
u(1)=0;
plot(t,coluna)
hold on;
plot(time,saida_sim);

