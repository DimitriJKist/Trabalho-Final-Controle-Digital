function cost=optimization_PID(k)
assignin("base",'k',k)
sim('sim_PID_PSO.slx')
cost=itae(length(itae));
end