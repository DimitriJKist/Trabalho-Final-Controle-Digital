#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "planta_e_controle_PD_I_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
#else
#include "builtin_typeid_types.h"
#include "planta_e_controle_PD_I.h"
#include "planta_e_controle_PD_I_capi.h"
#include "planta_e_controle_PD_I_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               ((NULL))
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , TARGET_STRING (
"planta_e_controle_PD_I/I /is_active_c2_planta_e_controle_PD_I" ) ,
TARGET_STRING ( "is_active_c2_planta_e_controle_PD_I" ) , 0 , 0 , 0 , 0 , 0 }
, { 1 , 0 , TARGET_STRING ( "planta_e_controle_PD_I/Abs" ) , TARGET_STRING (
"" ) , 0 , 1 , 0 , 0 , 0 } , { 2 , 0 , TARGET_STRING (
"planta_e_controle_PD_I/Clock" ) , TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 }
, { 3 , 0 , TARGET_STRING ( "planta_e_controle_PD_I/Integrator" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 4 , 0 , TARGET_STRING (
"planta_e_controle_PD_I/Integrator1" ) , TARGET_STRING ( "" ) , 0 , 1 , 0 , 0
, 1 } , { 5 , 0 , TARGET_STRING ( "planta_e_controle_PD_I/Integrator2" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 6 , 0 , TARGET_STRING (
"planta_e_controle_PD_I/Square" ) , TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 0
} , { 7 , 0 , TARGET_STRING ( "planta_e_controle_PD_I/Product" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 8 , 0 , TARGET_STRING (
"planta_e_controle_PD_I/Saturation" ) , TARGET_STRING ( "" ) , 0 , 1 , 0 , 0
, 0 } , { 9 , 0 , TARGET_STRING ( "planta_e_controle_PD_I/N�vel refer�ncia" )
, TARGET_STRING ( "entrada" ) , 0 , 1 , 0 , 0 , 2 } , { 10 , 0 ,
TARGET_STRING ( "planta_e_controle_PD_I/G(s) aproxima��o de pad�3" ) ,
TARGET_STRING ( "saida" ) , 0 , 1 , 0 , 0 , 1 } , { 0 , 0 , ( NULL ) , ( NULL
) , 0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_BlockParameters
rtBlockParameters [ ] = { { 11 , TARGET_STRING (
"planta_e_controle_PD_I/Data Store Memory" ) , TARGET_STRING ( "InitialValue"
) , 1 , 0 , 0 } , { 12 , TARGET_STRING (
"planta_e_controle_PD_I/Data Store Memory1" ) , TARGET_STRING (
"InitialValue" ) , 1 , 0 , 0 } , { 13 , TARGET_STRING (
"planta_e_controle_PD_I/Data Store Memory10" ) , TARGET_STRING (
"InitialValue" ) , 1 , 0 , 0 } , { 14 , TARGET_STRING (
"planta_e_controle_PD_I/Data Store Memory11" ) , TARGET_STRING (
"InitialValue" ) , 1 , 0 , 0 } , { 15 , TARGET_STRING (
"planta_e_controle_PD_I/Data Store Memory12" ) , TARGET_STRING (
"InitialValue" ) , 1 , 0 , 0 } , { 16 , TARGET_STRING (
"planta_e_controle_PD_I/Data Store Memory2" ) , TARGET_STRING (
"InitialValue" ) , 1 , 0 , 0 } , { 17 , TARGET_STRING (
"planta_e_controle_PD_I/Data Store Memory3" ) , TARGET_STRING (
"InitialValue" ) , 1 , 0 , 0 } , { 18 , TARGET_STRING (
"planta_e_controle_PD_I/Data Store Memory4" ) , TARGET_STRING (
"InitialValue" ) , 1 , 0 , 0 } , { 19 , TARGET_STRING (
"planta_e_controle_PD_I/Data Store Memory5" ) , TARGET_STRING (
"InitialValue" ) , 1 , 0 , 0 } , { 20 , TARGET_STRING (
"planta_e_controle_PD_I/Data Store Memory9" ) , TARGET_STRING (
"InitialValue" ) , 1 , 0 , 0 } , { 21 , TARGET_STRING (
"planta_e_controle_PD_I/Integrator" ) , TARGET_STRING ( "InitialCondition" )
, 1 , 0 , 0 } , { 22 , TARGET_STRING ( "planta_e_controle_PD_I/Integrator1" )
, TARGET_STRING ( "InitialCondition" ) , 1 , 0 , 0 } , { 23 , TARGET_STRING (
"planta_e_controle_PD_I/Integrator2" ) , TARGET_STRING ( "InitialCondition" )
, 1 , 0 , 0 } , { 24 , TARGET_STRING ( "planta_e_controle_PD_I/Saturation" )
, TARGET_STRING ( "UpperLimit" ) , 1 , 0 , 0 } , { 25 , TARGET_STRING (
"planta_e_controle_PD_I/Saturation" ) , TARGET_STRING ( "LowerLimit" ) , 1 ,
0 , 0 } , { 26 , TARGET_STRING ( "planta_e_controle_PD_I/N�vel refer�ncia" )
, TARGET_STRING ( "Time" ) , 1 , 0 , 0 } , { 27 , TARGET_STRING (
"planta_e_controle_PD_I/N�vel refer�ncia" ) , TARGET_STRING ( "Before" ) , 1
, 0 , 0 } , { 28 , TARGET_STRING ( "planta_e_controle_PD_I/N�vel refer�ncia"
) , TARGET_STRING ( "After" ) , 1 , 0 , 0 } , { 29 , TARGET_STRING (
"planta_e_controle_PD_I/G(s) aproxima��o de pad�3" ) , TARGET_STRING ( "A" )
, 1 , 1 , 0 } , { 30 , TARGET_STRING (
"planta_e_controle_PD_I/G(s) aproxima��o de pad�3" ) , TARGET_STRING ( "C" )
, 1 , 2 , 0 } , { 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 } } ; static int_T
rt_LoggedStateIdxList [ ] = { - 1 } ; static const rtwCAPI_Signals
rtRootInputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ;
static const rtwCAPI_Signals rtRootOutputs [ ] = { { 0 , 0 , ( NULL ) , (
NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_ModelParameters
rtModelParameters [ ] = { { 31 , TARGET_STRING ( "k" ) , 1 , 2 , 0 } , { 0 ,
( NULL ) , 0 , 0 , 0 } } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtDW . gcbzjlk0kk , & rtB . flwasteykl
, & rtB . kikh0am1qy , & rtB . if4gpb552f , & rtB . ghrss4whi4 , & rtB .
nbwbul5y5u , & rtB . g41dcod1nu , & rtB . ogcaub2axv , & rtB . gdi52fpkqd , &
rtB . kj3ghwxnfl , & rtB . c1awbkntj5 , & rtP . DataStoreMemory_InitialValue
, & rtP . DataStoreMemory1_InitialValue , & rtP .
DataStoreMemory10_InitialValue , & rtP . DataStoreMemory11_InitialValue , &
rtP . DataStoreMemory12_InitialValue , & rtP . DataStoreMemory2_InitialValue
, & rtP . DataStoreMemory3_InitialValue , & rtP .
DataStoreMemory4_InitialValue , & rtP . DataStoreMemory5_InitialValue , & rtP
. DataStoreMemory9_InitialValue , & rtP . Integrator_IC , & rtP .
Integrator1_IC , & rtP . Integrator2_IC , & rtP . Saturation_UpperSat , & rtP
. Saturation_LowerSat , & rtP . Nvelreferncia_Time , & rtP . Nvelreferncia_Y0
, & rtP . Nvelreferncia_YFinal , & rtP . Gsaproximaodepad3_A [ 0 ] , & rtP .
Gsaproximaodepad3_C [ 0 ] , & rtP . k [ 0 ] , } ; static int32_T *
rtVarDimsAddrMap [ ] = { ( NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { {
"unsigned char" , "uint8_T" , 0 , 0 , sizeof ( uint8_T ) , ( uint8_T )
SS_UINT8 , 0 , 0 , 0 } , { "double" , "real_T" , 0 , 0 , sizeof ( real_T ) ,
( uint8_T ) SS_DOUBLE , 0 , 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_VECTOR , 2 , 2 , 0 } , {
rtwCAPI_VECTOR , 4 , 2 , 0 } } ; static const uint_T rtDimensionArray [ ] = {
1 , 1 , 3 , 1 , 1 , 3 } ; static const real_T rtcapiStoredFloats [ ] = {
5.0E-5 , 0.0 , 1.0 } ; static const rtwCAPI_FixPtMap rtFixPtMap [ ] = { { (
NULL ) , ( NULL ) , rtwCAPI_FIX_RESERVED , 0 , 0 , ( boolean_T ) 0 } , } ;
static const rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * )
& rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 1 ] , (
int8_T ) 2 , ( uint8_T ) 0 } , { ( const void * ) & rtcapiStoredFloats [ 1 ]
, ( const void * ) & rtcapiStoredFloats [ 1 ] , ( int8_T ) 0 , ( uint8_T ) 0
} , { ( const void * ) & rtcapiStoredFloats [ 1 ] , ( const void * ) &
rtcapiStoredFloats [ 2 ] , ( int8_T ) 1 , ( uint8_T ) 0 } } ; static
rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 11 ,
rtRootInputs , 0 , rtRootOutputs , 0 } , { rtBlockParameters , 20 ,
rtModelParameters , 1 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 3008511923U , 2985467350U , 2607165042U , 2335002596U } , ( NULL ) , 0 ,
( boolean_T ) 0 , rt_LoggedStateIdxList } ; const
rtwCAPI_ModelMappingStaticInfo * planta_e_controle_PD_I_GetCAPIStaticMap (
void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void planta_e_controle_PD_I_InitializeDataMapInfo ( void ) {
rtwCAPI_SetVersion ( ( * rt_dataMapInfoPtr ) . mmi , 1 ) ;
rtwCAPI_SetStaticMap ( ( * rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ;
rtwCAPI_SetLoggingStaticMap ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetDataAddressMap ( ( * rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ;
rtwCAPI_SetVarDimsAddressMap ( ( * rt_dataMapInfoPtr ) . mmi ,
rtVarDimsAddrMap ) ; rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr )
. mmi , ( NULL ) ) ; rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi
, ( NULL ) ) ; rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi ,
0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void planta_e_controle_PD_I_host_InitializeDataMapInfo (
planta_e_controle_PD_I_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , ( NULL ) )
; rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetPath ( dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap ->
mmi , ( NULL ) ) ; rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
