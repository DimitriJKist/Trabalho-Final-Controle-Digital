#ifndef RTW_HEADER_planta_e_controle_PD_I_h_
#define RTW_HEADER_planta_e_controle_PD_I_h_
#ifndef planta_e_controle_PD_I_COMMON_INCLUDES_
#define planta_e_controle_PD_I_COMMON_INCLUDES_
#include <stdlib.h>
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "rtwtypes.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "planta_e_controle_PD_I_types.h"
#include <stddef.h>
#include "rtw_modelmap_simtarget.h"
#include "rt_defines.h"
#include <string.h>
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#define MODEL_NAME planta_e_controle_PD_I
#define NSAMPLE_TIMES (4) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (11) 
#define NUM_ZC_EVENTS (0) 
#ifndef NCSTATES
#define NCSTATES (6)   
#elif NCSTATES != 6
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T ghrss4whi4 ; real_T if4gpb552f ; real_T nbwbul5y5u ;
real_T kj3ghwxnfl ; real_T c1awbkntj5 ; real_T gdi52fpkqd ; real_T flwasteykl
; real_T ogcaub2axv ; real_T g41dcod1nu ; real_T kikh0am1qy ; } B ; typedef
struct { real_T ktvr43aorc ; real_T hh3rkgtxgz ; real_T nhnsrjzxsl ; real_T
njxzwwemq1 ; real_T d4pz1v3ueb ; real_T iouyt4amti ; real_T mqxd5jejgh ;
real_T grtkmh0y5y ; real_T pvhuz24nvq ; real_T hpmxxy2n5s ; struct { void *
LoggedData ; } hhom2peggx ; struct { void * LoggedData ; } d2zyy5jxur ;
struct { void * LoggedData [ 2 ] ; } li5v3tyyi4 ; struct { void * LoggedData
; } h5ighhg5rn ; struct { void * AQHandles ; } kj4hamo33m ; struct { void *
AQHandles ; } hsb3m3ihpc ; struct { void * AQHandles ; } nmk0te54i3 ; int32_T
i4qg4pylcl ; int_T hiqa2c4jjo ; uint8_T gcbzjlk0kk ; boolean_T cob0fsexck ; }
DW ; typedef struct { real_T ov2uq5o3i3 ; real_T jyp4g2up4q ; real_T
h1n0gyiyva ; real_T lpwhh41bnv [ 3 ] ; } X ; typedef struct { real_T
ov2uq5o3i3 ; real_T jyp4g2up4q ; real_T h1n0gyiyva ; real_T lpwhh41bnv [ 3 ]
; } XDot ; typedef struct { boolean_T ov2uq5o3i3 ; boolean_T jyp4g2up4q ;
boolean_T h1n0gyiyva ; boolean_T lpwhh41bnv [ 3 ] ; } XDis ; typedef struct {
real_T ov2uq5o3i3 ; real_T jyp4g2up4q ; real_T h1n0gyiyva ; real_T lpwhh41bnv
[ 3 ] ; } CStateAbsTol ; typedef struct { real_T ov2uq5o3i3 ; real_T
jyp4g2up4q ; real_T h1n0gyiyva ; real_T lpwhh41bnv [ 3 ] ; } CXPtMin ;
typedef struct { real_T ov2uq5o3i3 ; real_T jyp4g2up4q ; real_T h1n0gyiyva ;
real_T lpwhh41bnv [ 3 ] ; } CXPtMax ; typedef struct { real_T daqvw1evry ; }
ZCV ; typedef struct { rtwCAPI_ModelMappingInfo mmi ; } DataMapInfo ; struct
P_ { real_T k [ 3 ] ; real_T DataStoreMemory2_InitialValue ; real_T
DataStoreMemory4_InitialValue ; real_T DataStoreMemory5_InitialValue ; real_T
DataStoreMemory9_InitialValue ; real_T Integrator1_IC ; real_T Integrator_IC
; real_T Integrator2_IC ; real_T Nvelreferncia_Time ; real_T Nvelreferncia_Y0
; real_T Nvelreferncia_YFinal ; real_T Gsaproximaodepad3_A [ 3 ] ; real_T
Gsaproximaodepad3_C [ 3 ] ; real_T Saturation_UpperSat ; real_T
Saturation_LowerSat ; real_T DataStoreMemory_InitialValue ; real_T
DataStoreMemory1_InitialValue ; real_T DataStoreMemory10_InitialValue ;
real_T DataStoreMemory11_InitialValue ; real_T DataStoreMemory12_InitialValue
; real_T DataStoreMemory3_InitialValue ; } ; extern const char_T *
RT_MEMORY_ALLOCATION_ERROR ; extern B rtB ; extern X rtX ; extern DW rtDW ;
extern P rtP ; extern mxArray * mr_planta_e_controle_PD_I_GetDWork ( ) ;
extern void mr_planta_e_controle_PD_I_SetDWork ( const mxArray * ssDW ) ;
extern mxArray * mr_planta_e_controle_PD_I_GetSimStateDisallowedBlocks ( ) ;
extern const rtwCAPI_ModelMappingStaticInfo *
planta_e_controle_PD_I_GetCAPIStaticMap ( void ) ; extern SimStruct * const
rtS ; extern DataMapInfo * rt_dataMapInfoPtr ; extern
rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid )
; void MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T
tid ) ; void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model (
ssExecutionInfo * executionInfo ) ;
#endif
