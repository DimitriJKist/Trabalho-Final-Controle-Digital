#ifndef RTW_HEADER_planta_e_controle_PD_I_capi_h_
#define RTW_HEADER_planta_e_controle_PD_I_capi_h_
#include "planta_e_controle_PD_I.h"
extern void planta_e_controle_PD_I_InitializeDataMapInfo ( void ) ;
#endif
