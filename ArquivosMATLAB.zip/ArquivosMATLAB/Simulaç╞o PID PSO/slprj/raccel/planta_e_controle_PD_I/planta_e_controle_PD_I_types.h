#ifndef RTW_HEADER_planta_e_controle_PD_I_types_h_
#define RTW_HEADER_planta_e_controle_PD_I_types_h_
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
typedef struct P_ P ;
#endif
