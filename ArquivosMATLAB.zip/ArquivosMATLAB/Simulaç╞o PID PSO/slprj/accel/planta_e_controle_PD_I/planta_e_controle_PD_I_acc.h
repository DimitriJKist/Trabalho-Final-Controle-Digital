#ifndef RTW_HEADER_planta_e_controle_PD_I_acc_h_
#define RTW_HEADER_planta_e_controle_PD_I_acc_h_
#ifndef planta_e_controle_PD_I_acc_COMMON_INCLUDES_
#define planta_e_controle_PD_I_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn
#define S_FUNCTION_LEVEL 2
#ifndef RTW_GENERATED_S_FUNCTION
#define RTW_GENERATED_S_FUNCTION
#endif
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "planta_e_controle_PD_I_acc_types.h"
#include <stddef.h>
#include <float.h>
#include "mwmathutil.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T B_1_0_0 ; real_T B_1_1_8 ; real_T B_1_2_16 ; real_T
B_1_3_24 ; real_T B_1_4_32 ; real_T B_1_5_40 ; real_T B_1_6_48 ; real_T
B_1_7_56 ; real_T B_1_8_64 ; real_T B_1_9_72 ; real_T B_1_10_80 ; real_T
B_1_11_88 ; real_T B_1_12_96 ; real_T B_1_13_104 ; real_T B_1_14_112 ; real_T
B_1_15_120 ; real_T B_1_16_128 ; real_T B_1_17_136 ; real_T B_1_18_144 ;
real_T B_1_19_152 ; real_T B_1_20_160 ; real_T B_1_21_168 ; real_T B_0_22_176
; } B_planta_e_controle_PD_I_T ; typedef struct { real_T u_ant_av ; real_T
y_ant_av ; real_T e_ant_av ; real_T u_ant_kp ; real_T y_ant_kp ; real_T
u_I_ant_kp ; real_T u_D_ant ; real_T u_ant ; real_T y_ant ; real_T e_ant ;
real_T y_ant_2 ; real_T Du_D_ant ; real_T u_I_ant ; struct { real_T
modelTStart ; } TransportDelay_RWORK ; void * DataStoreMemory2_PWORK ; void *
DataStoreMemory4_PWORK ; void * DataStoreMemory5_PWORK ; void *
DataStoreMemory6_PWORK ; void * DataStoreMemory7_PWORK ; void *
DataStoreMemory8_PWORK ; void * DataStoreMemory9_PWORK ; void * Scope3_PWORK
; void * Scope_PWORK ; void * Scope1_PWORK ; void * Scope2_PWORK [ 2 ] ; void
* Scope4_PWORK ; struct { void * AQHandles ; }
_asyncqueue_inserted_for_ToWorkspace2_PWORK ; struct { void * AQHandles ; }
_asyncqueue_inserted_for_ToWorkspace4_PWORK ; struct { void * AQHandles ; }
_asyncqueue_inserted_for_ToWorkspace1_PWORK ; struct { void * TUbufferPtrs [
2 ] ; } TransportDelay_PWORK ; void * Scope5_PWORK [ 2 ] ; void *
DataStoreMemory_PWORK ; void * DataStoreMemory1_PWORK ; void *
DataStoreMemory10_PWORK ; void * DataStoreMemory11_PWORK ; void *
DataStoreMemory12_PWORK ; void * DataStoreMemory3_PWORK ; int32_T dsmIdx ;
int32_T dsmIdx_g ; int32_T dsmIdx_j ; int32_T dsmIdx_d ; int32_T dsmIdx_a ;
int32_T dsmIdx_k ; int32_T dsmIdx_b ; int32_T dsmIdx_o ; int32_T dsmIdx_b0 ;
int32_T dsmIdx_bw ; int32_T dsmIdx_jk ; int32_T dsmIdx_l ; int32_T dsmIdx_i ;
int32_T I_sysIdxToRun ; struct { int_T Tail ; int_T Head ; int_T Last ; int_T
CircularBufSize ; int_T MaxNewBufSize ; } TransportDelay_IWORK ; int_T
u65V1_MODE ; int_T Nvelreferncia_MODE ; int_T Step_MODE ; }
DW_planta_e_controle_PD_I_T ; typedef struct { real_T
Gsaproximaodepad1_CSTATE [ 2 ] ; real_T TransferFcn1_CSTATE ; real_T
TransferFcn_CSTATE ; real_T Integrator1_CSTATE ; real_T Integrator_CSTATE ;
real_T Integrator2_CSTATE ; real_T Gsaproximaodepad3_CSTATE [ 3 ] ; real_T
Gsaproximaodepad_CSTATE [ 2 ] ; real_T Gs_CSTATE ; }
X_planta_e_controle_PD_I_T ; typedef struct { real_T Gsaproximaodepad1_CSTATE
[ 2 ] ; real_T TransferFcn1_CSTATE ; real_T TransferFcn_CSTATE ; real_T
Integrator1_CSTATE ; real_T Integrator_CSTATE ; real_T Integrator2_CSTATE ;
real_T Gsaproximaodepad3_CSTATE [ 3 ] ; real_T Gsaproximaodepad_CSTATE [ 2 ]
; real_T Gs_CSTATE ; } XDot_planta_e_controle_PD_I_T ; typedef struct {
boolean_T Gsaproximaodepad1_CSTATE [ 2 ] ; boolean_T TransferFcn1_CSTATE ;
boolean_T TransferFcn_CSTATE ; boolean_T Integrator1_CSTATE ; boolean_T
Integrator_CSTATE ; boolean_T Integrator2_CSTATE ; boolean_T
Gsaproximaodepad3_CSTATE [ 3 ] ; boolean_T Gsaproximaodepad_CSTATE [ 2 ] ;
boolean_T Gs_CSTATE ; } XDis_planta_e_controle_PD_I_T ; typedef struct {
real_T Gsaproximaodepad1_CSTATE [ 2 ] ; real_T TransferFcn1_CSTATE ; real_T
TransferFcn_CSTATE ; real_T Integrator1_CSTATE ; real_T Integrator_CSTATE ;
real_T Integrator2_CSTATE ; real_T Gsaproximaodepad3_CSTATE [ 3 ] ; real_T
Gsaproximaodepad_CSTATE [ 2 ] ; real_T Gs_CSTATE ; }
CStateAbsTol_planta_e_controle_PD_I_T ; typedef struct { real_T
Gsaproximaodepad1_CSTATE [ 2 ] ; real_T TransferFcn1_CSTATE ; real_T
TransferFcn_CSTATE ; real_T Integrator1_CSTATE ; real_T Integrator_CSTATE ;
real_T Integrator2_CSTATE ; real_T Gsaproximaodepad3_CSTATE [ 3 ] ; real_T
Gsaproximaodepad_CSTATE [ 2 ] ; real_T Gs_CSTATE ; }
CXPtMin_planta_e_controle_PD_I_T ; typedef struct { real_T
Gsaproximaodepad1_CSTATE [ 2 ] ; real_T TransferFcn1_CSTATE ; real_T
TransferFcn_CSTATE ; real_T Integrator1_CSTATE ; real_T Integrator_CSTATE ;
real_T Integrator2_CSTATE ; real_T Gsaproximaodepad3_CSTATE [ 3 ] ; real_T
Gsaproximaodepad_CSTATE [ 2 ] ; real_T Gs_CSTATE ; }
CXPtMax_planta_e_controle_PD_I_T ; typedef struct { real_T u65V1_StepTime_ZC
; real_T Nvelreferncia_StepTime_ZC ; real_T Step_StepTime_ZC ; }
ZCV_planta_e_controle_PD_I_T ; typedef struct { ZCSigState u65V1_StepTime_ZCE
; ZCSigState Nvelreferncia_StepTime_ZCE ; ZCSigState Step_StepTime_ZCE ; }
PrevZCX_planta_e_controle_PD_I_T ; struct P_planta_e_controle_PD_I_T_ {
real_T P_0 [ 2 ] ; real_T P_1 [ 3 ] ; real_T P_2 ; real_T P_3 ; real_T P_4 ;
real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9 [ 2 ] ; real_T
P_10 [ 2 ] ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T
P_15 ; real_T P_16 ; real_T P_17 ; real_T P_18 ; real_T P_19 ; real_T P_20 ;
real_T P_21 ; real_T P_22 ; real_T P_23 ; real_T P_24 ; real_T P_25 ; real_T
P_26 [ 3 ] ; real_T P_27 [ 3 ] ; real_T P_28 ; real_T P_29 ; real_T P_30 ;
real_T P_31 ; real_T P_32 [ 2 ] ; real_T P_33 [ 2 ] ; real_T P_34 ; real_T
P_35 ; real_T P_36 ; real_T P_37 ; real_T P_38 ; real_T P_39 ; real_T P_40 ;
real_T P_41 ; real_T P_42 ; real_T P_43 ; real_T P_44 ; } ; extern
P_planta_e_controle_PD_I_T planta_e_controle_PD_I_rtDefaultP ;
#endif
