#include "planta_e_controle_PD_I_acc.h"
#include "planta_e_controle_PD_I_acc_types.h"
#include "mwmathutil.h"
#include "rtwtypes.h"
#include "planta_e_controle_PD_I_acc_private.h"
#include "multiword_types.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "simtarget/slSimTgtMdlrefSfcnBridge.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#ifndef __RTW_UTFREE__  
extern void * utMalloc ( size_t ) ; extern void utFree ( void * ) ;
#endif
boolean_T planta_e_controle_PD_I_acc_rt_TDelayUpdateTailOrGrowBuf ( int_T *
bufSzPtr , int_T * tailPtr , int_T * headPtr , int_T * lastPtr , real_T
tMinusDelay , real_T * * uBufPtr , boolean_T isfixedbuf , boolean_T
istransportdelay , int_T * maxNewBufSzPtr ) { int_T testIdx ; int_T tail = *
tailPtr ; int_T bufSz = * bufSzPtr ; real_T * tBuf = * uBufPtr + bufSz ;
real_T * xBuf = ( NULL ) ; int_T numBuffer = 2 ; if ( istransportdelay ) {
numBuffer = 3 ; xBuf = * uBufPtr + 2 * bufSz ; } testIdx = ( tail < ( bufSz -
1 ) ) ? ( tail + 1 ) : 0 ; if ( ( tMinusDelay <= tBuf [ testIdx ] ) && !
isfixedbuf ) { int_T j ; real_T * tempT ; real_T * tempU ; real_T * tempX = (
NULL ) ; real_T * uBuf = * uBufPtr ; int_T newBufSz = bufSz + 1024 ; if (
newBufSz > * maxNewBufSzPtr ) { * maxNewBufSzPtr = newBufSz ; } tempU = (
real_T * ) utMalloc ( numBuffer * newBufSz * sizeof ( real_T ) ) ; if ( tempU
== ( NULL ) ) { return ( false ) ; } tempT = tempU + newBufSz ; if (
istransportdelay ) tempX = tempT + newBufSz ; for ( j = tail ; j < bufSz ; j
++ ) { tempT [ j - tail ] = tBuf [ j ] ; tempU [ j - tail ] = uBuf [ j ] ; if
( istransportdelay ) tempX [ j - tail ] = xBuf [ j ] ; } for ( j = 0 ; j <
tail ; j ++ ) { tempT [ j + bufSz - tail ] = tBuf [ j ] ; tempU [ j + bufSz -
tail ] = uBuf [ j ] ; if ( istransportdelay ) tempX [ j + bufSz - tail ] =
xBuf [ j ] ; } if ( * lastPtr > tail ) { * lastPtr -= tail ; } else { *
lastPtr += ( bufSz - tail ) ; } * tailPtr = 0 ; * headPtr = bufSz ; utFree (
uBuf ) ; * bufSzPtr = newBufSz ; * uBufPtr = tempU ; } else { * tailPtr =
testIdx ; } return ( true ) ; } real_T
planta_e_controle_PD_I_acc_rt_TDelayInterpolate ( real_T tMinusDelay , real_T
tStart , real_T * uBuf , int_T bufSz , int_T * lastIdx , int_T oldestIdx ,
int_T newIdx , real_T initOutput , boolean_T discrete , boolean_T
minorStepAndTAtLastMajorOutput ) { int_T i ; real_T yout , t1 , t2 , u1 , u2
; real_T * tBuf = uBuf + bufSz ; if ( ( newIdx == 0 ) && ( oldestIdx == 0 )
&& ( tMinusDelay > tStart ) ) return initOutput ; if ( tMinusDelay <= tStart
) return initOutput ; if ( ( tMinusDelay <= tBuf [ oldestIdx ] ) ) { if (
discrete ) { return ( uBuf [ oldestIdx ] ) ; } else { int_T tempIdx =
oldestIdx + 1 ; if ( oldestIdx == bufSz - 1 ) tempIdx = 0 ; t1 = tBuf [
oldestIdx ] ; t2 = tBuf [ tempIdx ] ; u1 = uBuf [ oldestIdx ] ; u2 = uBuf [
tempIdx ] ; if ( t2 == t1 ) { if ( tMinusDelay >= t2 ) { yout = u2 ; } else {
yout = u1 ; } } else { real_T f1 = ( t2 - tMinusDelay ) / ( t2 - t1 ) ;
real_T f2 = 1.0 - f1 ; yout = f1 * u1 + f2 * u2 ; } return yout ; } } if (
minorStepAndTAtLastMajorOutput ) { if ( newIdx != 0 ) { if ( * lastIdx ==
newIdx ) { ( * lastIdx ) -- ; } newIdx -- ; } else { if ( * lastIdx == newIdx
) { * lastIdx = bufSz - 1 ; } newIdx = bufSz - 1 ; } } i = * lastIdx ; if (
tBuf [ i ] < tMinusDelay ) { while ( tBuf [ i ] < tMinusDelay ) { if ( i ==
newIdx ) break ; i = ( i < ( bufSz - 1 ) ) ? ( i + 1 ) : 0 ; } } else { while
( tBuf [ i ] >= tMinusDelay ) { i = ( i > 0 ) ? i - 1 : ( bufSz - 1 ) ; } i =
( i < ( bufSz - 1 ) ) ? ( i + 1 ) : 0 ; } * lastIdx = i ; if ( discrete ) {
double tempEps = ( DBL_EPSILON ) * 128.0 ; double localEps = tempEps *
muDoubleScalarAbs ( tBuf [ i ] ) ; if ( tempEps > localEps ) { localEps =
tempEps ; } localEps = localEps / 2.0 ; if ( tMinusDelay >= ( tBuf [ i ] -
localEps ) ) { yout = uBuf [ i ] ; } else { if ( i == 0 ) { yout = uBuf [
bufSz - 1 ] ; } else { yout = uBuf [ i - 1 ] ; } } } else { if ( i == 0 ) {
t1 = tBuf [ bufSz - 1 ] ; u1 = uBuf [ bufSz - 1 ] ; } else { t1 = tBuf [ i -
1 ] ; u1 = uBuf [ i - 1 ] ; } t2 = tBuf [ i ] ; u2 = uBuf [ i ] ; if ( t2 ==
t1 ) { if ( tMinusDelay >= t2 ) { yout = u2 ; } else { yout = u1 ; } } else {
real_T f1 = ( t2 - tMinusDelay ) / ( t2 - t1 ) ; real_T f2 = 1.0 - f1 ; yout
= f1 * u1 + f2 * u2 ; } } return ( yout ) ; } void rt_ssGetBlockPath (
SimStruct * S , int_T sysIdx , int_T blkIdx , char_T * * path ) {
_ssGetBlockPath ( S , sysIdx , blkIdx , path ) ; } void rt_ssSet_slErrMsg (
void * S , void * diag ) { SimStruct * castedS = ( SimStruct * ) S ; if ( !
_ssIsErrorStatusAslErrMsg ( castedS ) ) { _ssSet_slErrMsg ( castedS , diag )
; } else { _ssDiscardDiagnostic ( castedS , diag ) ; } } void
rt_ssReportDiagnosticAsWarning ( void * S , void * diag ) {
_ssReportDiagnosticAsWarning ( ( SimStruct * ) S , diag ) ; } void
rt_ssReportDiagnosticAsInfo ( void * S , void * diag ) {
_ssReportDiagnosticAsInfo ( ( SimStruct * ) S , diag ) ; } static void
mdlOutputs ( SimStruct * S , int_T tid ) { B_planta_e_controle_PD_I_T * _rtB
; DW_planta_e_controle_PD_I_T * _rtDW ; P_planta_e_controle_PD_I_T * _rtP ;
X_planta_e_controle_PD_I_T * _rtX ; int32_T isHit ; _rtDW = ( (
DW_planta_e_controle_PD_I_T * ) ssGetRootDWork ( S ) ) ; _rtX = ( (
X_planta_e_controle_PD_I_T * ) ssGetContStates ( S ) ) ; _rtP = ( (
P_planta_e_controle_PD_I_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_planta_e_controle_PD_I_T * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> B_1_0_0 =
0.0 ; _rtB -> B_1_0_0 += _rtP -> P_10 [ 0 ] * _rtX ->
Gsaproximaodepad1_CSTATE [ 0 ] ; _rtB -> B_1_0_0 += _rtP -> P_10 [ 1 ] * _rtX
-> Gsaproximaodepad1_CSTATE [ 1 ] ; ssCallAccelRunBlock ( S , 1 , 1 ,
SS_CALL_MDL_OUTPUTS ) ; isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0
) { _rtDW -> u65V1_MODE = ( ssGetTaskTime ( S , 1 ) >= _rtP -> P_11 ) ; if (
_rtDW -> u65V1_MODE == 1 ) { _rtB -> B_1_1_8 = _rtP -> P_13 ; } else { _rtB
-> B_1_1_8 = _rtP -> P_12 ; } } _rtB -> B_1_2_16 = _rtB -> B_1_1_8 - _rtB ->
B_1_0_0 ; _rtB -> B_1_3_24 = 0.0 ; _rtB -> B_1_3_24 += _rtP -> P_15 * _rtX ->
TransferFcn1_CSTATE ; _rtB -> B_1_3_24 += _rtP -> P_16 * _rtB -> B_1_2_16 ;
_rtB -> B_1_4_32 = 0.0 ; _rtB -> B_1_4_32 += _rtP -> P_18 * _rtX ->
TransferFcn_CSTATE ; _rtB -> B_1_4_32 += _rtP -> P_19 * _rtB -> B_1_0_0 ;
_rtB -> B_1_5_40 = _rtB -> B_1_3_24 - _rtB -> B_1_4_32 ; _rtB -> B_1_6_48 =
_rtX -> Integrator1_CSTATE ; ssCallAccelRunBlock ( S , 1 , 8 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_1_7_56 = _rtX -> Integrator_CSTATE ;
ssCallAccelRunBlock ( S , 1 , 10 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_1_8_64 =
_rtX -> Integrator2_CSTATE ; ssCallAccelRunBlock ( S , 1 , 12 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 1 , 13 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 1 , 14 ,
SS_CALL_MDL_OUTPUTS ) ; isHit = ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0
) { _rtDW -> Nvelreferncia_MODE = ( ssGetTaskTime ( S , 1 ) >= _rtP -> P_23 )
; if ( _rtDW -> Nvelreferncia_MODE == 1 ) { _rtB -> B_1_9_72 = _rtP -> P_25 ;
} else { _rtB -> B_1_9_72 = _rtP -> P_24 ; } } _rtB -> B_1_10_80 = 0.0 ; _rtB
-> B_1_10_80 += _rtP -> P_27 [ 0 ] * _rtX -> Gsaproximaodepad3_CSTATE [ 0 ] ;
_rtB -> B_1_10_80 += _rtP -> P_27 [ 1 ] * _rtX -> Gsaproximaodepad3_CSTATE [
1 ] ; _rtB -> B_1_10_80 += _rtP -> P_27 [ 2 ] * _rtX ->
Gsaproximaodepad3_CSTATE [ 2 ] ; ssCallAccelRunBlock ( S , 1 , 17 ,
SS_CALL_MDL_OUTPUTS ) ; isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0
) { _rtB -> B_1_11_88 = _rtB -> B_1_10_80 ; _rtB -> B_1_12_96 = _rtB ->
B_1_9_72 - _rtB -> B_1_11_88 ; ssCallAccelRunBlock ( S , 0 , 0 ,
SS_CALL_MDL_OUTPUTS ) ; if ( _rtB -> B_0_22_176 > _rtP -> P_28 ) { _rtB ->
B_1_13_104 = _rtP -> P_28 ; } else if ( _rtB -> B_0_22_176 < _rtP -> P_29 ) {
_rtB -> B_1_13_104 = _rtP -> P_29 ; } else { _rtB -> B_1_13_104 = _rtB ->
B_0_22_176 ; } ssCallAccelRunBlock ( S , 1 , 23 , SS_CALL_MDL_OUTPUTS ) ; }
isHit = ssIsSampleHit ( S , 3 , 0 ) ; if ( isHit != 0 ) { { if ( _rtDW ->
_asyncqueue_inserted_for_ToWorkspace2_PWORK . AQHandles && ssGetLogOutput ( S
) ) { sdiWriteSignal ( _rtDW -> _asyncqueue_inserted_for_ToWorkspace2_PWORK .
AQHandles , ssGetTaskTime ( S , 3 ) , ( char * ) & _rtB -> B_1_9_72 + 0 ) ; }
} { if ( _rtDW -> _asyncqueue_inserted_for_ToWorkspace4_PWORK . AQHandles &&
ssGetLogOutput ( S ) ) { sdiWriteSignal ( _rtDW ->
_asyncqueue_inserted_for_ToWorkspace4_PWORK . AQHandles , ssGetTaskTime ( S ,
3 ) , ( char * ) & _rtB -> B_1_8_64 + 0 ) ; } } } isHit = ssIsSampleHit ( S ,
2 , 0 ) ; if ( isHit != 0 ) { _rtB -> B_1_14_112 = muDoubleScalarAbs ( _rtB
-> B_1_12_96 ) ; } _rtB -> B_1_15_120 = _rtB -> B_1_14_112 * ssGetT ( S ) ;
isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0 ) { _rtB -> B_1_16_128
= _rtB -> B_1_12_96 * _rtB -> B_1_12_96 ; } _rtB -> B_1_17_136 = ssGetT ( S )
; isHit = ssIsSampleHit ( S , 3 , 0 ) ; if ( isHit != 0 ) { { if ( _rtDW ->
_asyncqueue_inserted_for_ToWorkspace1_PWORK . AQHandles && ssGetLogOutput ( S
) ) { sdiWriteSignal ( _rtDW -> _asyncqueue_inserted_for_ToWorkspace1_PWORK .
AQHandles , ssGetTaskTime ( S , 3 ) , ( char * ) & _rtB -> B_1_17_136 + 0 ) ;
} } } { real_T * * uBuffer = ( real_T * * ) & _rtDW -> TransportDelay_PWORK .
TUbufferPtrs [ 0 ] ; real_T simTime = ssGetT ( S ) ; real_T tMinusDelay =
simTime - _rtP -> P_30 ; _rtB -> B_1_18_144 =
planta_e_controle_PD_I_acc_rt_TDelayInterpolate ( tMinusDelay , 0.0 , *
uBuffer , _rtDW -> TransportDelay_IWORK . CircularBufSize , & _rtDW ->
TransportDelay_IWORK . Last , _rtDW -> TransportDelay_IWORK . Tail , _rtDW ->
TransportDelay_IWORK . Head , _rtP -> P_31 , 0 , ( boolean_T ) (
ssIsMinorTimeStep ( S ) && ( ( * uBuffer + _rtDW -> TransportDelay_IWORK .
CircularBufSize ) [ _rtDW -> TransportDelay_IWORK . Head ] == ssGetT ( S ) )
) ) ; } _rtB -> B_1_19_152 = 0.0 ; _rtB -> B_1_19_152 += _rtP -> P_33 [ 0 ] *
_rtX -> Gsaproximaodepad_CSTATE [ 0 ] ; _rtB -> B_1_19_152 += _rtP -> P_33 [
1 ] * _rtX -> Gsaproximaodepad_CSTATE [ 1 ] ; ssCallAccelRunBlock ( S , 1 ,
34 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_1_20_160 = 0.0 ; _rtB -> B_1_20_160 +=
_rtP -> P_35 * _rtX -> Gs_CSTATE ; isHit = ssIsSampleHit ( S , 1 , 0 ) ; if (
isHit != 0 ) { _rtDW -> Step_MODE = ( ssGetTaskTime ( S , 1 ) >= _rtP -> P_36
) ; if ( _rtDW -> Step_MODE == 1 ) { _rtB -> B_1_21_168 = _rtP -> P_38 ; }
else { _rtB -> B_1_21_168 = _rtP -> P_37 ; } } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) {
B_planta_e_controle_PD_I_T * _rtB ; DW_planta_e_controle_PD_I_T * _rtDW ;
P_planta_e_controle_PD_I_T * _rtP ; _rtDW = ( ( DW_planta_e_controle_PD_I_T *
) ssGetRootDWork ( S ) ) ; _rtP = ( ( P_planta_e_controle_PD_I_T * )
ssGetModelRtp ( S ) ) ; _rtB = ( ( B_planta_e_controle_PD_I_T * )
_ssGetModelBlockIO ( S ) ) ; { real_T * * uBuffer = ( real_T * * ) & _rtDW ->
TransportDelay_PWORK . TUbufferPtrs [ 0 ] ; real_T simTime = ssGetT ( S ) ;
_rtDW -> TransportDelay_IWORK . Head = ( ( _rtDW -> TransportDelay_IWORK .
Head < ( _rtDW -> TransportDelay_IWORK . CircularBufSize - 1 ) ) ? ( _rtDW ->
TransportDelay_IWORK . Head + 1 ) : 0 ) ; if ( _rtDW -> TransportDelay_IWORK
. Head == _rtDW -> TransportDelay_IWORK . Tail ) { if ( !
planta_e_controle_PD_I_acc_rt_TDelayUpdateTailOrGrowBuf ( & _rtDW ->
TransportDelay_IWORK . CircularBufSize , & _rtDW -> TransportDelay_IWORK .
Tail , & _rtDW -> TransportDelay_IWORK . Head , & _rtDW ->
TransportDelay_IWORK . Last , simTime - _rtP -> P_30 , uBuffer , ( boolean_T
) 0 , false , & _rtDW -> TransportDelay_IWORK . MaxNewBufSize ) ) {
ssSetErrorStatus ( S , "tdelay memory allocation error" ) ; return ; } } ( *
uBuffer + _rtDW -> TransportDelay_IWORK . CircularBufSize ) [ _rtDW ->
TransportDelay_IWORK . Head ] = simTime ; ( * uBuffer ) [ _rtDW ->
TransportDelay_IWORK . Head ] = _rtB -> B_1_20_160 ; } UNUSED_PARAMETER ( tid
) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { B_planta_e_controle_PD_I_T *
_rtB ; P_planta_e_controle_PD_I_T * _rtP ; XDot_planta_e_controle_PD_I_T *
_rtXdot ; X_planta_e_controle_PD_I_T * _rtX ; _rtXdot = ( (
XDot_planta_e_controle_PD_I_T * ) ssGetdX ( S ) ) ; _rtX = ( (
X_planta_e_controle_PD_I_T * ) ssGetContStates ( S ) ) ; _rtP = ( (
P_planta_e_controle_PD_I_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_planta_e_controle_PD_I_T * ) _ssGetModelBlockIO ( S ) ) ; _rtXdot ->
Gsaproximaodepad1_CSTATE [ 0 ] = 0.0 ; _rtXdot -> Gsaproximaodepad1_CSTATE [
0 ] += _rtP -> P_9 [ 0 ] * _rtX -> Gsaproximaodepad1_CSTATE [ 0 ] ; _rtXdot
-> Gsaproximaodepad1_CSTATE [ 1 ] = 0.0 ; _rtXdot -> Gsaproximaodepad1_CSTATE
[ 0 ] += _rtP -> P_9 [ 1 ] * _rtX -> Gsaproximaodepad1_CSTATE [ 1 ] ; _rtXdot
-> Gsaproximaodepad1_CSTATE [ 1 ] += _rtX -> Gsaproximaodepad1_CSTATE [ 0 ] ;
_rtXdot -> Gsaproximaodepad1_CSTATE [ 0 ] += _rtB -> B_1_5_40 ; _rtXdot ->
TransferFcn1_CSTATE = 0.0 ; _rtXdot -> TransferFcn1_CSTATE += _rtP -> P_14 *
_rtX -> TransferFcn1_CSTATE ; _rtXdot -> TransferFcn1_CSTATE += _rtB ->
B_1_2_16 ; _rtXdot -> TransferFcn_CSTATE = 0.0 ; _rtXdot ->
TransferFcn_CSTATE += _rtP -> P_17 * _rtX -> TransferFcn_CSTATE ; _rtXdot ->
TransferFcn_CSTATE += _rtB -> B_1_0_0 ; _rtXdot -> Integrator1_CSTATE = _rtB
-> B_1_14_112 ; _rtXdot -> Integrator_CSTATE = _rtB -> B_1_16_128 ; _rtXdot
-> Integrator2_CSTATE = _rtB -> B_1_15_120 ; _rtXdot ->
Gsaproximaodepad3_CSTATE [ 0 ] = 0.0 ; _rtXdot -> Gsaproximaodepad3_CSTATE [
0 ] += _rtP -> P_26 [ 0 ] * _rtX -> Gsaproximaodepad3_CSTATE [ 0 ] ; _rtXdot
-> Gsaproximaodepad3_CSTATE [ 1 ] = 0.0 ; _rtXdot -> Gsaproximaodepad3_CSTATE
[ 0 ] += _rtP -> P_26 [ 1 ] * _rtX -> Gsaproximaodepad3_CSTATE [ 1 ] ;
_rtXdot -> Gsaproximaodepad3_CSTATE [ 2 ] = 0.0 ; _rtXdot ->
Gsaproximaodepad3_CSTATE [ 0 ] += _rtP -> P_26 [ 2 ] * _rtX ->
Gsaproximaodepad3_CSTATE [ 2 ] ; _rtXdot -> Gsaproximaodepad3_CSTATE [ 0 ] +=
_rtB -> B_1_13_104 ; _rtXdot -> Gsaproximaodepad3_CSTATE [ 1 ] += _rtX ->
Gsaproximaodepad3_CSTATE [ 0 ] ; _rtXdot -> Gsaproximaodepad_CSTATE [ 0 ] =
0.0 ; _rtXdot -> Gsaproximaodepad_CSTATE [ 0 ] += _rtP -> P_32 [ 0 ] * _rtX
-> Gsaproximaodepad_CSTATE [ 0 ] ; _rtXdot -> Gsaproximaodepad3_CSTATE [ 2 ]
+= _rtX -> Gsaproximaodepad3_CSTATE [ 1 ] ; _rtXdot ->
Gsaproximaodepad_CSTATE [ 1 ] = 0.0 ; _rtXdot -> Gsaproximaodepad_CSTATE [ 0
] += _rtP -> P_32 [ 1 ] * _rtX -> Gsaproximaodepad_CSTATE [ 1 ] ; _rtXdot ->
Gsaproximaodepad_CSTATE [ 1 ] += _rtX -> Gsaproximaodepad_CSTATE [ 0 ] ;
_rtXdot -> Gsaproximaodepad_CSTATE [ 0 ] += _rtB -> B_1_21_168 ; _rtXdot ->
Gs_CSTATE = 0.0 ; _rtXdot -> Gs_CSTATE += _rtP -> P_34 * _rtX -> Gs_CSTATE ;
_rtXdot -> Gs_CSTATE += _rtB -> B_1_21_168 ; }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { P_planta_e_controle_PD_I_T *
_rtP ; ZCV_planta_e_controle_PD_I_T * _rtZCSV ; _rtZCSV = ( (
ZCV_planta_e_controle_PD_I_T * ) ssGetSolverZcSignalVector ( S ) ) ; _rtP = (
( P_planta_e_controle_PD_I_T * ) ssGetModelRtp ( S ) ) ; _rtZCSV ->
u65V1_StepTime_ZC = ssGetT ( S ) - _rtP -> P_11 ; _rtZCSV ->
Nvelreferncia_StepTime_ZC = ssGetT ( S ) - _rtP -> P_23 ; _rtZCSV ->
Step_StepTime_ZC = ssGetT ( S ) - _rtP -> P_36 ; } static void
mdlInitializeSizes ( SimStruct * S ) { ssSetChecksumVal ( S , 0 , 3253701424U
) ; ssSetChecksumVal ( S , 1 , 4180623618U ) ; ssSetChecksumVal ( S , 2 ,
3496767943U ) ; ssSetChecksumVal ( S , 3 , 2122812310U ) ; { mxArray *
slVerStructMat = ( NULL ) ; mxArray * slStrMat = mxCreateString ( "simulink"
) ; char slVerChar [ 10 ] ; int status = mexCallMATLAB ( 1 , & slVerStructMat
, 1 , & slStrMat , "ver" ) ; if ( status == 0 ) { mxArray * slVerMat =
mxGetField ( slVerStructMat , 0 , "Version" ) ; if ( slVerMat == ( NULL ) ) {
status = 1 ; } else { status = mxGetString ( slVerMat , slVerChar , 10 ) ; }
} mxDestroyArray ( slStrMat ) ; mxDestroyArray ( slVerStructMat ) ; if ( (
status == 1 ) || ( strcmp ( slVerChar , "23.2" ) != 0 ) ) { return ; } }
ssSetOptions ( S , SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork (
S ) != ( SLSize ) sizeof ( DW_planta_e_controle_PD_I_T ) ) { static char msg
[ 256 ] ; snprintf ( msg , 256 , "Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file (%ld vs %lu)." , ( signed long )
ssGetSizeofDWork ( S ) , ( unsigned long ) sizeof (
DW_planta_e_controle_PD_I_T ) ) ; ssSetErrorStatus ( S , msg ) ; } if (
ssGetSizeofGlobalBlockIO ( S ) != ( SLSize ) sizeof (
B_planta_e_controle_PD_I_T ) ) { static char msg [ 256 ] ; snprintf ( msg ,
256 , "Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file (%ld vs %lu)." , ( signed long )
ssGetSizeofGlobalBlockIO ( S ) , ( unsigned long ) sizeof (
B_planta_e_controle_PD_I_T ) ) ; ssSetErrorStatus ( S , msg ) ; } { int
ssSizeofParams ; ssGetSizeofParams ( S , & ssSizeofParams ) ; if (
ssSizeofParams != sizeof ( P_planta_e_controle_PD_I_T ) ) { static char msg [
256 ] ; snprintf ( msg , 256 ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file (%d vs %lu)." , ssSizeofParams , (
unsigned long ) sizeof ( P_planta_e_controle_PD_I_T ) ) ; ssSetErrorStatus (
S , msg ) ; } } _ssSetModelRtp ( S , ( real_T * ) &
planta_e_controle_PD_I_rtDefaultP ) ; rt_InitInfAndNaN ( sizeof ( real_T ) )
; } static void mdlInitializeSampleTimes ( SimStruct * S ) { { SimStruct *
childS ; SysOutputFcn * callSysFcns ; childS = ssGetSFunction ( S , 0 ) ;
callSysFcns = ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ]
= ( SysOutputFcn ) ( NULL ) ; } } static void mdlTerminate ( SimStruct * S )
{ }
#include "simulink.c"
