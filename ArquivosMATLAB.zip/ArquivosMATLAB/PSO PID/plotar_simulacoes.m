% Plotar ângulo de referência
plot(time, entrada+120, 'r-', 'LineWidth', 1.5);
hold on;
plot(time, saida+120, 'b-', 'LineWidth', 1.5);

% Melhorar os rótulos e título
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Ângulo (°)', 'FontSize', 12, 'FontWeight', 'bold');
title('Resposta Angular do Motor CC', 'FontSize', 14, 'FontWeight', 'bold');
% Ajustar limites dos eixos
xlim([0 8]);
ylim([120 200]);

% Adicionar legenda para identificação das curvas
legend({'Posição Angular (Saída)', 'Ângulo de Referência'}, 'FontSize', 11, 'Location', 'best');

% Ajustar os eixos