% Script de inicialização para o Simulink

% Inicializar as variáveis globais
u_ant = 0;      % Valor inicial do controle (u[n-1])
y_ant = 0;      % Valor inicial da saída (y[n-1])
u_I_ant = 0;    % Valor inicial da integral (termo I anterior)
u_D_ant = 0;    % Valor inicial do derivativo (termo D anterior)

% Configurar parâmetros do sistema
Ts = 1 / 10e3;    % Período de amostragem (em segundos)
K_P = 0.8;        % Ganho proporcional (Kp)
T_I = 50;        % Constante de tempo do integrador (Ti)
T_D = 0.5;      % Constante de tempo derivativa (Td)
sat = 10;       % Saturação do controlador
N = 15;        % Fator de filtro derivativo

% Criar vetor de parâmetros
k = [K_P, T_I, T_D];

assignin('base', 'k', k);

% Mensagem de conclusão
disp('Variáveis globais e parâmetros inicializados no Workspace.');

% Initial Parameters
n_var = 3; % Number of variables: [K_P,T_I,T_D]
% Lower and upper bounds for the variables
rng(42);
lb = [0.1,   0.3, 0.05]; % Lower bounds
ub = [2, 1, 0.8]; % Upper bounds
nPart = 20; 
max_iter = 25; 
w_range = [0.2 0.9];

% PSO options

pso_opt = optimoptions("particleswarm", 'SwarmSize', nPart, ...
    'MaxIterations', max_iter, 'InertiaRange', w_range, ...
    "Display", "iter", 'PlotFcn', 'pswplotbestf');
obj_fn = @(k) optimization_PID(k);

% PSO command
% x = particleswarm(fun, nvars, lb, ub, options)
[k, fval, exitflag] = particleswarm(obj_fn, n_var, lb, ub, pso_opt);

function cost=optimization_PID(k)
assignin("base",'k',k)
sim('planta_e_controle_PD_I.slx')
cost=itae(length(itae));
end

