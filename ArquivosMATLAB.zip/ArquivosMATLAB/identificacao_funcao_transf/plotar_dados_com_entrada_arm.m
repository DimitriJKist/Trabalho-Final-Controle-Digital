% Ler os dados da tabela
data = readtable('kp=1_160_inicial.dat');

% Selecionar a coluna da posição angular (ajuste conforme necessário)
coluna = data.x16519200000000Fa05; 
coluna = coluna-coluna(1);
coluna=coluna*2;
% Criar vetor de tempo
t = linspace(0, 4, length(coluna))';

% Criar o ângulo de referência (degrau de 180°)
u = 40 * ones(length(coluna), 1);
u(1) = 0;


% Criar figura
figure;
hold on;
grid on;
box on; % Para formato mais técnico
plot(t, u, 'Color','[0.3010 0.7450 0.9330]', 'LineWidth', 4);

% Plotar a posição angular (dados experimentais)
plot(t, coluna, 'b-', 'LineWidth', 2);

% Plotar a resposta ao degrau do modelo estimado

% Melhorar os rótulos e título
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Ângulo (°)', 'FontSize', 12, 'FontWeight', 'bold');
title('Comparação entre Dados Experimentais e Modelo Estimado', 'FontSize', 14, 'FontWeight', 'bold');

% Adicionar legenda
legend({'Referência', 'Saída'}, 'FontSize', 11, 'Location', 'best');

% Ajustar limites dos eixos
xlim([-0.1 4]);
ylim([min(coluna) - 2, max(coluna) + 2]);

% Exibir o gráfico
hold off;
