    
   load("funcao_transferencia_identificada.mat")
    % Obter a função de transferência de malha aberta G(s) = Gmf(s) / (1 - Gmf(s))
    tf_open_loop = tf2 / (1 - tf2);

% Exibir os resultados
disp('Função de transferência de malha aberta G(s):');
tf_open_loop

[num, den] = tfdata(tf_open_loop, 'v');

k=[0.85 0.3 0.11];

