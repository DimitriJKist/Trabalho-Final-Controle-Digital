% Ler os dados da tabela
data = readtable('kp=1_160_inicial.dat');

% Selecionar a coluna da posição angular (ajuste conforme necessário)
coluna = data.x16519200000000Fa05; 
coluna = coluna-coluna(1)
% Criar vetor de tempo
t = linspace(0, 4, length(coluna))';
coluna = coluna*2;
% Criar o ângulo de referência (degrau de 180°)
u = 40 * ones(length(coluna), 1);
u(1) = 0;

% Definir a função de transferência estimada (tf6)
load("funcao_transferencia_identificada.mat")

% Simular a resposta ao degrau com tempo compatível
[y_modelo, t_modelo] = step(tf1, t);

% Ajustar a amplitude do degrau para 180° (igual ao experimento)
y_modelo = y_modelo*33.8400; 

% Criar figura
figure;
hold on;
grid on;
box on; % Para formato mais técnico
plot(t_modelo, y_modelo, 'Color','[0.3010 0.7450 0.9330]', 'LineWidth', 4);

% Plotar a posição angular (dados experimentais)
plot(t, coluna, 'b-.', 'LineWidth', 2);

% Plotar a resposta ao degrau do modelo estimado

% Melhorar os rótulos e título
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Ângulo (°)', 'FontSize', 12, 'FontWeight', 'bold');
title('Comparação entre Dados Experimentais e Modelo Estimado', 'FontSize', 14, 'FontWeight', 'bold');

% Adicionar legenda
legend({ 'Modelo estimado','Dados Experimentais'}, 'FontSize', 11, 'Location', 'best');

% Ajustar limites dos eixos
xlim([0 4]);
ylim([min(coluna) - 2, max(coluna) + 2]);

% Exibir o gráfico
hold off;
