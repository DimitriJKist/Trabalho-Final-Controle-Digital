
load("funcao_transferencia_identificada.mat")
% Obter a função de transferência de malha aberta G(s) = Gmf(s) / (1 - Gmf(s))
tf_open_loop = tf6 / (1 - tf6);

% Exibir os resultados
disp('Função de transferência de malha aberta G(s):');
tf_open_loop

[num, den] = tfdata(tf_open_loop, 'v');



