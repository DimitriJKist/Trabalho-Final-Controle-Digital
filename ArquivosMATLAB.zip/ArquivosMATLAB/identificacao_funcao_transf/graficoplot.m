% Ler os dados da tabela
data = readtable('kp=1_160_inicial.dat');

% Selecionar a coluna da posição angular
coluna = data.x16519200000000Fa05; % Ajuste conforme o nome da coluna real

% Criar vetor de tempo
t = linspace(0, 4, length(coluna))';
u = 18 * ones(length(coluna), 1); % Ângulo de referência
u(1) = 0; % Ajuste inicial
coluna=coluna-coluna(1);
% Criar figura para plotagem
figure;
hold on;
grid on;
box on; % Caixa ao redor para formato mais técnico

% Plotar posição angular (saída do sistema)
plot(t, coluna, 'b-', 'LineWidth', 1.5);

% Plotar ângulo de referência
plot(t, u, 'r--', 'LineWidth', 1.5);

% Melhorar os rótulos e título
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Ângulo (°)', 'FontSize', 12, 'FontWeight', 'bold');
title('Resposta Angular do Motor CC', 'FontSize', 14, 'FontWeight', 'bold');

% Adicionar legenda para identificação das curvas
legend({'Posição Angular (Saída)', 'Ângulo de Referência'}, 'FontSize', 11, 'Location', 'best');

% Ajustar os eixos
xlim([0 4]);
ylim([min(coluna) - 2, max(coluna) + 2]);

% Exibir o gráfico
hold off;
data = iddata(coluna,u,1/1000);

