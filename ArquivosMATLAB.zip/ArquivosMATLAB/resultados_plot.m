% Ler os dados da tabela
data = readtable('120_angulo.dat');

% Selecionar a coluna a ser filtrada
coluna = data.x16519200000000Fa05;
t = linspace(0, 8, length(coluna));
t = t';

% Sinal de entrada
u = 180 * ones(length(coluna), 1);
u(1) = 0;

% Criar a figura
figure;
hold on;
grid on;

% Plotar os dados experimentais
plot(t, coluna, 'b', 'LineWidth', 1.5);

% Plotar a saída simulada
plot(time, saida_sim120 + 120, '-r', 'LineWidth', 1.5);

% Melhorar a formatação do gráfico
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Ângulo (°)', 'FontSize', 12, 'FontWeight', 'bold');
title('Resposta do Motor CC - Entrada de 120°', 'FontSize', 14, 'FontWeight', 'bold');
legend({'Dados Experimentais', 'Simulação'}, 'FontSize', 11, 'Location', 'best');

% Ajustar limites dos eixos
xlim([0 8]);
ylim([min(coluna)-10 max(coluna)+10]);


%data = readtable('140_angulo.dat');
%coluna = data.x16519200000000Fa05;
%figure;
%plot(t,coluna)
%title('140')
%hold on;
%plot(time,saida_sim140+140);

%data = readtable('130_angulo.dat');
%coluna = data.x16519200000000Fa05;
%figure;
%plot(t,coluna)
%title('130')
%hold on;
%plot(time,saida_sim130+130);