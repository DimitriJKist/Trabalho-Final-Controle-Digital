% Ler os dados da tabela
data = readtable('respsota_controlador_FINAL_140_inicial.dat');
load('dados_simulados_140_inicial.mat')
% Selecionar a coluna a ser filtrada
coluna = data.x16519200000000Fa05;
t = linspace(0, 4, length(coluna));
t = t';

% Sinal de entrada
u = 180 * ones(length(coluna), 1);
u(1) = 0;

% Criar a figura
figure;
hold on;
grid on;

entrada_sim160(1)=0;
% Plotar os dados experimentais
plot(time, entrada_sim140+140, 'b', 'LineWidth', 1.5);

% Plotar a saída simulada
plot(time, saida_sim140 + 140, '-r', 'LineWidth', 1.5);

% Melhorar a formatação do gráfico
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Ângulo (°)', 'FontSize', 12, 'FontWeight', 'bold');
title('Resposta do Motor CC - Entrada de 120°', 'FontSize', 14, 'FontWeight', 'bold');
legend({'Dados Experimentais', 'Simulação'}, 'FontSize', 11, 'Location', 'best');

% Ajustar limites dos eixos
xlim([0 4]);
ylim([min(coluna)-2 max(coluna)+2]);


%data = readtable('140_angulo.dat');
%coluna = data.x16519200000000Fa05;
%figure;
%plot(t,coluna)
%title('140')
%hold on;
%plot(time,saida_sim140+140);

%data = readtable('130_angulo.dat');
%coluna = data.x16519200000000Fa05;
%figure;
%plot(t,coluna)
%title('130')
%hold on;
%plot(time,saida_sim130+130);