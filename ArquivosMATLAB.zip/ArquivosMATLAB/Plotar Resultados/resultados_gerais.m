load('dados_simulados_140_inicial.mat')
% Ler os dados da tabela
data = readtable('V_saida_COM_FILTRO.dat');
vsaida = data.x16519200000000Fa05;
data=readtable('Up_COM_FILTRO.dat');
up = data.x16519200000000Fa05;
up(isnan(udsemfiltro)) = 0;
data=readtable('Ui_COM_FILTRO.dat');
ui = data.x16519200000000Fa05;
ui(isnan(udsemfiltro)) = 0;
data=readtable('Ud_FILTRADO_COM_FILTRO.dat');
ud = data.x16519200000000Fa05;
ud(isnan(ud)) = 0;
data=readtable('Ud_COM_FILTRO.dat');
udsemfiltro = data.x16519200000000Fa05;
udsemfiltro(isnan(udsemfiltro)) = 0;
data=readtable('Corrente_COM_FILTRO.dat');
imotor = data.x16519200000000Fa05;
data=readtable('angulo_so pra teste pae2.dat');
anguloteste=data.x16519200000000Fa05;
u=up+ud+ui;
u(isnan(u)) = 0;
t = linspace(0, 4, length(ud));
t = t';

% Criar a figura
figure;
hold on;
grid on;


% Ajustar limites dos eixos
xlim([0 4]);
ylim([min(imotor)-1 max(imotor)+1]);

figure;
plot(t, ud, 'b', 'LineWidth', 1.5);
hold on;
grid on;
plot(t, up, 'r', 'LineWidth', 1.5);
plot(t, ui, 'g', 'LineWidth', 1.5);
legend({'Derivativo','Proporcional', 'Integrador'}, 'FontSize', 11, 'Location', 'best');
% Ajustar limites dos eixos
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Tensão (V)', 'FontSize', 12, 'FontWeight', 'bold');
xlim([0 4]);
ylim([-27 36]);

figure;
plot(t, vsaida, 'b', 'LineWidth', 1.5);
hold on;
grid on;
plot(time, v_saida_sim140, 'r', 'LineWidth', 1.5);
legend({'Experimental', 'Simulacao'}, 'FontSize', 11, 'Location', 'best');
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Tensão (V)', 'FontSize', 12, 'FontWeight', 'bold');


figure;
plot(t, anguloteste, 'b', 'LineWidth', 1.5);
hold on;
plot(time, saida, 'r', 'LineWidth', 1.5);
legend({'Experimental', 'Simulacao'}, 'FontSize', 11, 'Location', 'best');
% Melhorar a formatação do gráfico
grid on;
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Ângulo (°)', 'FontSize', 12, 'FontWeight', 'bold');

figure;
plot(t, udsemfiltro, 'b', 'LineWidth', 2);
hold on;
plot(t, ud, 'r', 'LineWidth', 1.5);
legend({'Derivativo', 'Derivativo com filtro'}, 'FontSize', 11, 'Location', 'best');
% Melhorar a formatação do gráfico
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Tensão (V)', 'FontSize', 12, 'FontWeight', 'bold');
grid on;

figure;
plot(t, u, 'b', 'LineWidth', 2);
hold on;
plot(time, esforco_sim140, 'r', 'LineWidth', 1.5);
legend({'Experimental', 'Simulado'}, 'FontSize', 11, 'Location', 'best');
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Tensão (V)', 'FontSize', 12, 'FontWeight', 'bold');
% Melhorar a formatação do gráfico
grid on;

% Substituir NaN por 0
imotor(isnan(imotor)) = 0;

% Parâmetros do filtro passa-baixa
Fs = 1 / mean(diff(t)); % Frequência de amostragem (inverso do passo de tempo)
Fc = 50; % Frequência de corte do filtro (ajuste conforme necessário)
ordem = 4; % Ordem do filtro

% Criar o filtro Butterworth passa-baixa
[b, a] = butter(ordem, Fc / (Fs / 2), 'low');

% Aplicar o filtro na corrente
imotor_filtrado = filtfilt(b, a, imotor);

% Plotar os dados
figure;
plot(t, imotor, 'b', 'LineWidth', 1.2); hold on;
plot(t, imotor_filtrado, 'r', 'LineWidth', 1.5); hold off;

% Melhorar a formatação do gráfico
xlabel('Tempo (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Corrente (A)', 'FontSize', 12, 'FontWeight', 'bold');
grid on;
title('Corrente do Motor - Original e Filtrada', 'FontSize', 14, 'FontWeight', 'bold');
legend({'Experimental', 'Filtrada'}, 'FontSize', 11, 'Location', 'best');