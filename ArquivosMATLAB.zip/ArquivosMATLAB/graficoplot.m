% Ler os dados da tabela
data = readtable('teste_100_angulo.dat');

% Selecionar a coluna a ser filtrada
coluna = data.x16519200000000Fa05;
t = linspace(0, 8, length(coluna));
t = t';
coluna=coluna-coluna(1);
u=40*ones(length(coluna),1);
u(1)=0;
plot(t,coluna)
hold on;
plot(t,u);
data = iddata(coluna,u,1/500);

